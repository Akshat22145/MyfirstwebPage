document.getElementById('bookingForm').addEventListener('submit', function(event) {
  event.preventDefault();
  const name = document.getElementById('name').value;
  const email = document.getElementById('email').value;
  const address = document.getElementById('address').value;
  const timeSlot = document.getElementById('timeSlot').value;

  if (name && email && address && timeSlot) {
    alert(`Booking Successful!\nName: ${name}\nEmail: ${email}\nAddress: ${address}\nTime: ${timeSlot}`);
  } 
  else {
    alert('Please fill out all fields.');
  }
});