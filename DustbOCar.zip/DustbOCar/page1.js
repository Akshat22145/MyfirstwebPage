// Toggle between login and registration forms
function toggleForm() {
    const loginForm = document.getElementById("login");
    const registerForm = document.getElementById("register");
    loginForm.style.display = loginForm.style.display === "none" ? "block" : "none";
    registerForm.style.display = registerForm.style.display === "none" ? "block" : "none";
}

// Handle login
document.getElementById("loginForm").addEventListener("submit", function (e) {
    e.preventDefault();
    alert("Login sucessfully");
    document.getElementById("login").style.display = "none";
    document.getElementById("booking").style.display = "block";
});

// Handle registration
document.getElementById("registerForm").addEventListener("submit", function (e) {
    e.preventDefault();
    alert("Registration form....!");
    toggleForm();
});

// Handle booking
document.getElementById("bookingForm").addEventListener("submit", function (e) {
    e.preventDefault();
    const timeSlot = document.getElementById("timeSlot").value;
    alert(`Slot booked for ${timeSlot}!`);
});